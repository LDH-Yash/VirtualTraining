package com.cg.dao;

import java.util.List;

import com.cg.entity.Product;

public interface ProductDaoI {

	public void addProduct(Product product);
	public List<Product> getAllProduct();
	public Product getProduct(int id);
	
}
