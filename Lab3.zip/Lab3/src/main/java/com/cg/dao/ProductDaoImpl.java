package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.Product;

@Repository
@Transactional
public class ProductDaoImpl implements ProductDaoI {

	@PersistenceContext
	EntityManager manager;
	
	@Override
	public void addProduct(Product product) {
		manager.persist(product);
	}

	@Override
	public List<Product> getAllProduct() {
	  Query query = manager.createQuery("from Product p");
	  
		return query.getResultList();
	}

	@Override
	public Product getProduct(int id) {
		Product prod = manager.find(Product.class, id);
		return prod;
	}

}
