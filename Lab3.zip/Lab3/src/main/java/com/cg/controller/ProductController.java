package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Product;
import com.cg.service.ServiceI;
import com.cg.service.ServiceImpl;

@RestController
public class ProductController {

	@Autowired
	ServiceI serv;
	
	@GetMapping(value="/product", produces= {"application/json"})
	public List<Product> getList()
	{
		return serv.getAllProduct();
	}
	
	@GetMapping(value="/product/{id}", produces= {"application/json"})
	public Product getProd(@PathVariable int id)
	{
		return serv.getProduct(id);
	}
	
	@PostMapping(value="/product/add", consumes= {"application/json"})
	public String addProduct(@RequestBody Product product)
	{
		serv.addProduct(product);
		return "add product";
	}
	
}
