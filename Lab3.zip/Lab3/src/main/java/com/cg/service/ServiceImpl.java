package com.cg.service;

import java.util.List;

import com.cg.dao.ProductDaoI;
import com.cg.entity.Product;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ServiceImpl implements ServiceI {

	@Autowired
	ProductDaoI dao;
	
	@Override
	public void addProduct(Product product) {
		// TODO Auto-generated method stub
		dao.addProduct(product);
	}

	@Override
	public List<Product> getAllProduct() {
		// TODO Auto-generated method stub
		return dao.getAllProduct();
	}

	@Override
	public Product getProduct(int id) {
		// TODO Auto-generated method stub
		return dao.getProduct(id);
	}

	
}
