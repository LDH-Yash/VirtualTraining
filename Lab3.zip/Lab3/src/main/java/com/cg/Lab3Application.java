package com.cg;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.cg.entity.Product;
import com.cg.service.ServiceImpl;

@SpringBootApplication
public class Lab3Application implements CommandLineRunner{

	@Autowired
	ServiceImpl serv;
	
	public static void main(String[] args) {
		SpringApplication.run(Lab3Application.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		
//		Product product = new Product(101, "Laptop", 2002);
//		serv.addProduct(product);
		
	}

}
