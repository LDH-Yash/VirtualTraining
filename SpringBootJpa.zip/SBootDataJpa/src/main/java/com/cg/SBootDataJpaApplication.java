package com.cg;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.cg.dao.StudentDaoI;
import com.cg.entity.Student;

@SpringBootApplication
public class SBootDataJpaApplication {

	@Autowired
	StudentDaoI dao;
	
	public static void main(String[] args) {
		SpringApplication.run(SBootDataJpaApplication.class, args);
	}

//	@Override
//	public void run(String... args) throws Exception {
//		// TODO Auto-generated method stub
//		
////		Student stu1 = new Student(3, "Sumit Pandey", 20);
////		Student stu2 = new Student(4, "ani pandey", 21);
////		
////		dao.create(stu1);
////		dao.create(stu2);
////		
////		System.out.println("inserted");
//		
//		List<Student> list = dao.retrieve();
//		
//		for(Student stu : list)
//		{
//			System.out.println("id "+stu.getId()+" name "+stu.getName()+" age "+stu.getAge());
//		}
//		
//		Student student = dao.findById(2);
//		System.out.println(student);
//	}

}
