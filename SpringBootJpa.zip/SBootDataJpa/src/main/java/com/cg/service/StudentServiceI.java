package com.cg.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.entity.Student;

@Service
public interface StudentServiceI {

	public void create(Student student);
	public List<Student> retrieve();
	public Student findById(int id);
	public void delete(int id);
	
	public void updateStudent(Student student);
}
