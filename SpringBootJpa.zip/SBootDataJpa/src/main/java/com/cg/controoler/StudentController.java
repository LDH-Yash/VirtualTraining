package com.cg.controoler;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Student;
import com.cg.service.StudentServiceI;

import oracle.net.aso.r;

@CrossOrigin(origins="http://localhost:4200")
@RestController
public class StudentController {

	@Autowired
	StudentServiceI service;
	
	@GetMapping(value = "/student")
	public List<Student> fetchStudent()
	{
		return service.retrieve();
	}
	
	@GetMapping(value = "/student/{id}")
	public Student fetchOneStudent(@PathVariable int id)
	{
		return service.findById(id);
	}
	
	@PostMapping(value = "/student/new", consumes= {"application/json"})
	public String addStudent(@RequestBody Student student)
	{
		service.create(student);
		return "student added";
	}
	
	@DeleteMapping(value="/student/delete/{id}")
	public String deleteStudent(@PathVariable int id)
	{
		service.delete(id);
		return "deleted";
	}
	
	@PutMapping(value="/student/update", consumes= {"application/json"})
	public String updateStudent(@RequestBody Student student)
	{
		service.updateStudent(student);
		return "updated";
	}
}
