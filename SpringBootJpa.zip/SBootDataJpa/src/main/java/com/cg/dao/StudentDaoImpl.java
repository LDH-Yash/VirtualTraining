package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.Student;

@Repository
@Transactional
public class StudentDaoImpl implements StudentDaoI{

	@PersistenceContext
	EntityManager manager;
	
	@Override
	public void create(Student student) {
		// TODO Auto-generated method stub
		manager.persist(student);
	}

	@Override
	public List<Student> retrieve() {
		
		Query query =  manager.createQuery("from Student s");
		
		return query.getResultList();
	}

	@Override
	public Student findById(int id) {
		// TODO Auto-generated method stub
		Student student = manager.find(Student.class, id);
		return student;
	}

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		Student student = manager.find(Student.class, id);
		manager.remove(student);
	}

	@Override
	public void updateStudent(Student student) {

       Student student2 = manager.find(Student.class, student.getId());
       
       student2.setAge(student.getAge());
       student2.setId(student.getId());
       student2.setName(student.getName());
		
	}
	

}
