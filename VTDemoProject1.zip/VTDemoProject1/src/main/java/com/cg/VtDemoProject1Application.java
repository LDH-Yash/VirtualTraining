package com.cg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VtDemoProject1Application {

	public static void main(String[] args) {
		SpringApplication.run(VtDemoProject1Application.class, args);
	}

}
