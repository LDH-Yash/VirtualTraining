package com.cg.entity;

public class Stu {
	public String name;
	public int dept;
	public int id;
	public String university;

	public Stu() {
		
	}

	public Stu(String name, int dept, int id, String university) {
		super();
		this.name = name;
		this.dept = dept;
		this.id = id;
		this.university = university;
	}

	
}

