import { Component, OnInit, ViewChild } from '@angular/core';
import { Student } from '../student';
import { NgForm } from '@angular/forms';
import { FetchService } from '../fetch.service';
import { Router } from '@angular/router';
import { error } from '@angular/compiler/src/util';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {

  @ViewChild("#formdata")
  form:NgForm

  constructor(private service:FetchService, private router:Router) { }

student:Student = new Student();

  ngOnInit(): void {
    this.student = this.service.getStudent();
  }

updateUser()
{
    alert(this.student.name);

    this.service.updateUser(this.student).subscribe(data=>
      {
        alert("updated successfully");
        this.router.navigateByUrl('/view');
      }, 
      error=>
      {
        console.log("error occured", error);
        
      }
      );
}

}
