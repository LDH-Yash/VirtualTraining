import { Component, OnInit, ViewChild } from '@angular/core';
import { Student } from '../student';
import { FetchService } from '../fetch.service';
import { error } from '@angular/compiler/src/util';
import { NgModel, NgForm } from '@angular/forms';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {

  constructor(private service:FetchService) { }

@ViewChild(NgModel)
form:NgForm

  stu:Student = new Student();

  ngOnInit(): void {
  }

  createUser()
  {

    alert(this.stu.id);
    this.service.createNewStudent(this.stu).subscribe(data =>
      {
        alert("student added successfully");
      },
      error=>
      {
        console.log("error occured", error);
      }
      );
  }

}
