import { Component, OnInit } from '@angular/core';
import { FetchService } from '../fetch.service';
import { Student } from '../student';
import { error } from '@angular/compiler/src/util';

@Component({
  selector: 'app-view-student',
  templateUrl: './view-student.component.html',
  styleUrls: ['./view-student.component.css']
})
export class ViewStudentComponent implements OnInit {

  constructor(private service:FetchService) { }

  students:Student[]=[];
  id:number;
  stud:Student = new Student();

  ngOnInit(): void {

      this.service.loadData().subscribe(data=>
      {this.students = data}, 
      error =>
      {console.log("error occured", error);
      }
      );
  }

 deleteUser(index:number)
 {
    this.id = this.students[index].id;
    
    this.service.deleteUser(this.id).subscribe(data=>
      {
        alert("deleted successfully");

        this.ngOnInit();
      },
      error=>
      {
        console.log("error", error);
        
      }
      );
 }

 update(index:number)
 {
   this.stud = this.students[index];
   
   this.service.setStudent(this.stud)
 }

}
