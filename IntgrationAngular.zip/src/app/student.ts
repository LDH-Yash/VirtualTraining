export class Student {

id:number;
name:string;
age:number;

}
