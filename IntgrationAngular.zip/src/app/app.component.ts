import { Component } from '@angular/core';
import { FetchService } from './fetch.service';
import { Student } from './student';
import { error } from '@angular/compiler/src/util';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'covid19';

  myresponse:Student[];
  

   constructor(private service:FetchService){}

  getAllStudents()
  {
      this.service.loadData().subscribe(data=>{this.myresponse = data}, 
      error =>{console.log("error occured", error);
      });
     
  }

  // deleteStudent(id:Number)
  // {

  //   alert("id is"+id)
  //   this._http.delete(this.APP_URL +'/delete/'+id).subscribe( () => console.log("deleted")
  //   );
  // }
}
