import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Student } from './student';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class FetchService {

  students:Student[]=[];
  stud:Student = new Student();

  constructor(private _http:HttpClient) { }

  loadData():Observable<any>
  {
      let url = "http://localhost:3000/student";
      
      return this._http.get(url);
  }

  createNewStudent(student:Student):Observable<any>
  {
    let url = "http://localhost:3000/student/new"
    return this._http.post(url, student,{responseType:'text'})
  }
 
  deleteUser(id:number):Observable<any>
  {
    let url= "http://localhost:3000/student/delete/"+id;
    return this._http.delete(url, {responseType:'text'});
  }

updateUser(student:Student):Observable<any>
{
  let url = "http://localhost:3000/student/update";
  return this._http.put(url, student, {responseType:'text'});
}

setStudent(student:Student)
{
  this.stud = student;
}

getStudent():Student
{
  return this.stud;
}

}
