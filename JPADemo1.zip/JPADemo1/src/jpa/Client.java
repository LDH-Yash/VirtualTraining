package jpa;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class Client {

	public static void main(String[] args) {
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("per1");
		
		EntityManager em=emf.createEntityManager();
		
		em.getTransaction().begin();
		
//		Student s1=new Student();
//		s1.setId(11);
//		s1.setName("rohan");
//		s1.setDept("hr");
//		
//		System.out.println("inserted");
//
//		Student s2=new Student();
//		s2.setId(31);
//		s2.setName("Yash");
//		s2.setDept("developer");
//		
//		System.out.println("inserted");
//		
//		em.persist(s1);
//		em.persist(s2);
		
//		Student stu = em.find(Student.class, 2);
//		System.out.println("Before");
//		System.out.println("ID: " + stu.getId());
//		System.out.println("Name: " + stu.getName());
//		System.out.println("Dept: " + stu.getDept());
//		
//		stu.setName("Yash");
//		stu.setDept("CEO");
//		
//		System.out.println("After");
//		System.out.println("ID: " + stu.getId());
//		System.out.println("Name: " + stu.getName());
//		System.out.println("Dept: " + stu.getDept());
		
//		System.out.println("updated");
		
//		Student stu = em.find(Student.class, 21);
//		System.out.println("Before");
//		System.out.println(stu);
//		
//		em.remove(stu);
//		
//		System.out.println("After");
//		System.out.println(stu);
//		
//		System.out.println("deleted");
		
		
		
//		Student s1=new Student();
//		//s1.setId(63);
//		s1.setName("YashYo");
//		s1.setDept("hr");	
//		
//		
//		Student s2=new Student();
//		//s2.setId(68);
//		s2.setName("Swagger");
//		s2.setDept("hq");
//		em.persist(s1);
//		em.persist(s2);
//		em.getTransaction().commit();
//		System.out.println("inserted");
		
		Query query = em.createQuery("Select s from Student s");  
         
        @SuppressWarnings("unchecked")
		List<Student> list =query.getResultList();  
        System.out.println("Student Name");  
        for(Student s:list) 
        {
        	System.out.println("   "+s.getName());       
        }  
		
		em.close();

	}

}
